package rtdonin.ClassWork_9_22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassWork922Application {

	public static void main(String[] args) {
		SpringApplication.run(ClassWork922Application.class, args);
	}

}
