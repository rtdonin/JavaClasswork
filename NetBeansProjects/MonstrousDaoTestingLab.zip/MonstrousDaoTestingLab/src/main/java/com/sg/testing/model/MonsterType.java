/*********************************
* The Software Guild
* Copyright (C) 2020 Wiley edu LLC - All Rights Reserved
*********************************/
package com.sg.testing.model;

public enum MonsterType {
    YETI, SWAMPTHING, LIZARDMAN, WEREWOLF, VAMPIRE
}
