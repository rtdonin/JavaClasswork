/*
Created by: Margaret Donin
Date created: 06/30/20
Date revised:
*/

package flooring.dao;

public class FlooringAuditDaoImpl implements FlooringAuditDao {

    private String AUDIT_FILE;
    
    @Override
    public void writeAuditEntry(String entry) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
