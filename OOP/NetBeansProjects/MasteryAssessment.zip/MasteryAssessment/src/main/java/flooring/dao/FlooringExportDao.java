/*
Created by: Margaret Donin
Date created: 06/25/20
Date revised:
*/

package flooring.dao;

import flooring.dto.Order;
import java.util.List;

public interface FlooringExportDao {
    /**
     * Method iterates through a List of orders.
     * As it iterated through the list it converts each object into a string.
     * A List of Strings is returned.
     * 
     * @param List of allOrders
     * @return List of Strings
     */
    public List<String> createBackup(List<Order> allOrders);
}
