/*
Created by: Margaret Donin
Date created: 06/30/20
Date revised:
*/

package flooring.dao;

public interface FlooringAuditDao {
    public void writeAuditEntry(String entry);
}
