/*
Created by: Margaret Donin
Date created: 06/30/20
Date revised:
*/

package flooring.advice;

import flooring.dao.FlooringAuditDao;
import org.aspectj.lang.JoinPoint;

public class LoggingAdvice {
    FlooringAuditDao auditDao;
    
    public LoggingAdvice(FlooringAuditDao auditDao) {
        this.auditDao = auditDao;
    }
    
    public void createAuditEntry(JoinPoint jp) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
