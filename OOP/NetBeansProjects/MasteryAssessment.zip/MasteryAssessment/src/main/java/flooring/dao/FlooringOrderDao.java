/*
Created by: Margaret Donin
Date created: 06/25/20
Date revised:
*/

package flooring.dao;

import flooring.dto.Order;
import java.time.LocalDate;
import java.util.List;

public interface FlooringOrderDao {
    /**
     * 
     * @param date with which to look up the file to create a Map from
     * @return Map with id as an Integer as a key for the appropriate Order
     */
    public List<Order> getAllOrders(LocalDate date);
    public Order getOrder(LocalDate date, Integer id);
    public Order addOrder(Order newOrder);
    public Order editOrder(Order editedOrder);
    public Order removeOrder(Order removeOrder);
    public List<Order> exportAll();
}
