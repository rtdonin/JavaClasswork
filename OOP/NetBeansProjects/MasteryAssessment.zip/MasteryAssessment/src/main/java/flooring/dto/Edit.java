/*
Created by: Margaret Donin
Date created:
Date revised:
*/

package flooring.dto;

public enum Edit {
    CUSTOMER_NAME,
    STATE,
    PRODUCT_TYPE,
    AREA;
}
