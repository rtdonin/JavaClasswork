/*
Created by: Margaret Donin
Date created: 06/25/20
Date revised:
*/

package flooring.controller;

import flooring.service.FlooringServiceLayer;
import flooring.ui.FlooringView;

public class FlooringController {
    FlooringView view;
    FlooringServiceLayer service;

    public FlooringController(FlooringView view, FlooringServiceLayer service) {
        this.view = view;
        this.service = service;
    }
    
    public void run() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    private void getAllOrders() {
        throw new UnsupportedOperationException("Not supported yet.");    
    }
    
    private void addOrder() {
        throw new UnsupportedOperationException("Not supported yet.");    
    }
    
    private void editOrder() {
        throw new UnsupportedOperationException("Not supported yet.");    
    }
    
    private void removeOrder() {
        throw new UnsupportedOperationException("Not supported yet.");    
    }
    
    private void export() {
        throw new UnsupportedOperationException("Not supported yet.");    
    }
}