/*
Created by: Margaret Donin
Date created: 06/26/20
Date revised:
*/

package flooring.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FlooringOrderDaoImplTest {
    
    private FlooringOrderDao testDao;
    
    public FlooringOrderDaoImplTest() {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("appContext.xml");
        testDao = ctx.getBean("orderDao", FlooringOrderDao.class);
    }
    
    @BeforeEach
    public void setUp() {
    }

    @Test
    public void getAllOrdersFromDateTest() {
        // fail("The test case is a prototype.");
    }
    
    @Test
    public void getOrderTest() {
        // fail("The test case is a prototype.");
    }
    
    @Test
    public void addOrderTest() {
        // fail("The test case is a prototype.");
    }
    
    @Test
    public void editOrderTest() {
        // fail("The test case is a prototype.");
    }
    
    @Test
    public void removeOrderTest() {
        // fail("The test case is a prototype.");
    }
    
    @Test
    public void getAllOrdersTest() {
        // fail("The test case is a prototype.");
    }
    
}
